const form = document.getElementById("bookingForm");
const message = document.getElementById("message");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const name = document.getElementById("fullName").value.trim();
  const email = document.getElementById("email").value.trim();
  const sport = document.getElementById("sport").value;

  // clear old errors / message
  document.getElementById("nameError").textContent = "";
  document.getElementById("emailError").textContent = "";
  document.getElementById("sportError").textContent = "";
  message.textContent = "";

  let valid = true;

  if (name === "") {
    document.getElementById("nameError").textContent = "Full name is required.";
    valid = false;
  }
  if (email === "") {
    document.getElementById("emailError").textContent = "Email is required.";
    valid = false;
  }
  if (sport === "") {
    document.getElementById("sportError").textContent = "Please select a sport.";
    valid = false;
  }

  if (!valid) {
    alert("Please fill in all fields.");
    return;
  }

  message.textContent = "Booked " + name + " for " + sport + ".";
  form.reset();
});
