export interface Equipment {
  id: number
  item: string
  category: string
}

export const equipmentData: Equipment[] = [
  { id: 1, item: 'Yoga Mat', category: 'Fitness' },
  { id: 2, item: 'Badminton Racket', category: 'Sports' },
  { id: 3, item: 'Resistance Band', category: 'Fitness' },
]
