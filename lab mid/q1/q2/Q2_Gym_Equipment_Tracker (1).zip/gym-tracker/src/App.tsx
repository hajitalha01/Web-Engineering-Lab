import { useState } from 'react'
import EquipmentRow from './EquipmentRow'
import { equipmentData } from './types'
import type { Equipment } from './types'

function App() {
  // lifted state: list of checked-out IDs
  const [checkedOut, setCheckedOut] = useState<number[]>([])

  const handleToggle = (id: number) => {
    setCheckedOut((prev) =>
      prev.includes(id)
        ? prev.filter((x) => x !== id) // check in
        : [...prev, id]                // check out
    )
  }

  return (
    <div className="container">
      <h1>Gym Equipment Tracker</h1>

      <table>
        <caption>Gym equipment list</caption>
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Item</th>
            <th scope="col">Category</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {equipmentData.map((eq: Equipment) => (
            <EquipmentRow
              key={eq.id}
              equipment={eq}
              checkedOut={checkedOut.includes(eq.id)}
              onToggle={handleToggle}
            />
          ))}
        </tbody>
      </table>

      <p className="summary">
        {checkedOut.length} of {equipmentData.length} items checked out.
      </p>
    </div>
  )
}

export default App
