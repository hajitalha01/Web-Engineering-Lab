import type { Equipment } from './types'

interface EquipmentRowProps {
  equipment: Equipment
  checkedOut: boolean
  onToggle: (id: number) => void
}

function EquipmentRow({ equipment, checkedOut, onToggle }: EquipmentRowProps) {
  return (
    <tr className={checkedOut ? 'checked-out' : ''}>
      <td>{equipment.id}</td>
      <td>{equipment.item}</td>
      <td>{equipment.category}</td>
      <td>
        <button onClick={() => onToggle(equipment.id)}>
          {checkedOut ? 'Check in' : 'Check out'}
        </button>
      </td>
    </tr>
  )
}

export default EquipmentRow
